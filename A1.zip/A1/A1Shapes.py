# COMP1010 Assignment 1 Part 1 Provided Code
# Do not change anything in this file.

# Do not change this code. Skip down to the area provided for your code.
def draw_up_triangle():
    print('   /\\') # \ is a special character, so to make an actual \ we need \\
    print('  /  \\')
    print(' /    \\')

def draw_down_triangle():
    print(' \\    /')
    print('  \\  /')
    print('   \\/')

def draw_box():
    print('+------+')
    print('|      |')
    print('|      |')
    print('+------+')
